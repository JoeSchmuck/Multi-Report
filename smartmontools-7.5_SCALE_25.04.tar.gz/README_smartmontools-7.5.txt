These files were created from the smartmontools 7.5 distro.
The instructions below are for both CORE and SCALE builds.
These builds are different as CORE is FreeBSD based and SCALE is Debian Linux based.  They are not interchangable.


-----------------------------------------------------------------------

This set of files was created on TrueNAS CORE 13.3

Instructions for CORE only

Enter the following commands:

midclt call service.stop smartd
tar -xvf smartmontools-7.5_CORE_13.3.tar.gz -C /
reboot


----------------------------------------------------------------------

This set of files was created on TrueNAS SCALE 25.04.1

Instructions for SCALE only

Enter the following commands:

mount -o remount,rw '/usr'
romount="true"
midclt call service.stop smartd
tar -xvf smartmontools-7.5_SCALE_25.04.tar.gz -C /
reboot
