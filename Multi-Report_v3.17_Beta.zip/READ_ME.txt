The attached file are BETA.

WARNING WARNING WARNING
Multi-Report v3.17 will change the multi_report_config.txt file and it will NOT be backwards compatible.
Drive-Selftest v1.05 also uses the new configuration file if it exists.

This is a Beta and I do not see any further changes being rolled in at this time except maybe a little more cleanup of the script.
I need to work on the User Guides and hopefully that will be concluded NLT 30 May.

If you find a problem, please toss me an email to: joeschmuck2023@gmail.com or leave a comment on Github, or a message on TrueNAS forums.